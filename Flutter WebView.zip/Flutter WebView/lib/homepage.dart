
import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';


class Homepage extends StatefulWidget {
  @override
  _Homepage createState() => _Homepage();
}
class _Homepage extends State<Homepage> {
  
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: WebviewScaffold(
        url: 'https://panel.krztv.pro/',
        ignoreSSLErrors: true,
      ),
    );
  }
}
